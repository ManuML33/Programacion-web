import './App.css';
import Eleccion from './Cars';

export default function App() {
  return (
    <div className="App">
      <Eleccion/>
    </div>
  );
}


