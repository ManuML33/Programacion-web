import React from "react";

 export default function Boton() {
    return (
        <form>
            <div className="eleccion">
                <h1>Elige tu carro preferido</h1>
                    <select name="cars" id="cars">
                        <option value="volvo">Volvo</option>
                        <option value="saab">Saab</option>
                        <option value="mercedes">Mercedes</option>
                        <option value="audi">Audi</option>
                    </select>
                    <br></br>
                <input type="submit" value="Elejir"/>
            </div>
    
        </form>
        
    );
  }